Name: Kweku Ofori
Assignment: Lab5
Lab: MW 9:00AM-10:15AM
I did not colloborate with anyone on this assignment


There are two files contained in the foloder, 'Node.java' and 'Lab5.java'.


The Lab5 Class has the naming convention as per the lab manual instruction and contains all the neceesary method required
which performs the output as expected for implementing a trie. It also contains the main method for the string trie inputs.

The Node class contains node declarartion for left and right nodes and stored data and also checks for leaf and a branch.

